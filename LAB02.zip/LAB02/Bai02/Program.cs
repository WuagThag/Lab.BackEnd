﻿using System;
namespace Bai03
{
    class Program
    {
        // Hàm đếm số lượng số âm, số dương
        static void CountPositiveNegative(int[] arr, out int positiveCount, out int negativeCount)
        {
            positiveCount = 0;
            negativeCount = 0;
            foreach (int num in arr)
            {
                if (num > 0)
                {
                    positiveCount++;
                }
                else if (num < 0)
                {
                    negativeCount++;
                }
            }
        }

        static void Main(string[] args)
        {
            try
            {
                // Nhập số lượng phần tử
                Console.Write("Nhap so luong phan tu cua mang: ");
                int n = int.Parse(Console.ReadLine());

                // Kiểm tra số lượng phần tử hợp lệ
                if (n <= 0)
                {
                    Console.WriteLine("So luong phan tu phai lon hon 0!");
                    return;
                }

                // Khởi tạo mảng
                int[] numbers = new int[n];

                // Nhập từng phần tử
                for (int i = 0; i < n; i++)
                {
                    Console.Write($"Nhap phan tu thu {i + 1}: ");
                    numbers[i] = int.Parse(Console.ReadLine());
                }

                // Tính và hiển thị kết quả
                int positiveCount, negativeCount;
                CountPositiveNegative(numbers, out positiveCount, out negativeCount);
                Console.WriteLine($"\nSo luong so duong: {positiveCount}");
                Console.WriteLine($"So luong so am: {negativeCount}");
            }
            catch (FormatException)
            {
                Console.WriteLine("Vui long nhap so nguyen hop le!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Loi: {ex.Message}");
            }
        }
    }
}