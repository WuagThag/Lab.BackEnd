﻿using System;
namespace Bai01;
class Program
{
    // Hàm tính tổng các số chẵn
    static int SumEvenNumbers(int[] arr)
    {
        int sum = 0;
        foreach (int num in arr)
        {
            if (num % 2 == 0)
            {
                sum += num;
            }
        }
        return sum;
    }

    static void Main(string[] args)
    {
        try
        {
            // Nhập số lượng phần tử
            Console.Write("Nhap so luong phan tu cua mang: ");
            int n = int.Parse(Console.ReadLine());

            // Kiểm tra số lượng phần tử hợp lệ
            if (n <= 0)
            {
                Console.WriteLine("So luong phan tu phai lon hon 0!");
                return;
            }

            // Khởi tạo mảng
            int[] numbers = new int[n];

            // Nhập từng phần tử
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhap phan tu thu {i + 1}: ");
                numbers[i] = int.Parse(Console.ReadLine());
            }

            // Tính và hiển thị kết quả
            int result = SumEvenNumbers(numbers);
            Console.WriteLine($"\nTong cac so chan: {result}");

            // Hiển thị các số chẵn
            Console.Write("Cac so chan trong mang: ");
            bool hasEven = false;
            foreach (int num in numbers)
            {
                if (num % 2 == 0)
                {
                    Console.Write(num + " ");
                    hasEven = true;
                }
            }
            if (!hasEven)
            {
                Console.Write("Khong co so chan nao");
            }
        }
        catch (FormatException)
        {
            Console.WriteLine("Vui long nhap so nguyen hop le!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Loi: {ex.Message}");
        }
    }
}