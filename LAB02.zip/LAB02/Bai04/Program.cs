﻿using System;
namespace Bai04;
// viết hàm hoán  vị 2 số nguyên a và b nhập từ bàn phím
class Program
{
    static void HoanDoi(ref int a, ref int b)
    {
        int temp = a;
        a = b;
        b = temp;
    }
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        // Khai báo biến a, b
        int a, b;
        // Nhập giá trị cho biến a, b
        Console.Write("Nhập a: ");
        a = int.Parse(Console.ReadLine());
        Console.Write("Nhập b: ");
        b = int.Parse(Console.ReadLine());
        // Gọi hàm HoanDoi
        HoanDoi(ref a, ref b);
        // Hiển thị kết quả
        Console.WriteLine($"Sau khi hoán đổi: a = {a}, b = {b}");
    }
}