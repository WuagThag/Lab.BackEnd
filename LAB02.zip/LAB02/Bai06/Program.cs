﻿using System;
namespace Bai06;
//viết hàm  sắp xếp mảng  số thực n  phần tử nhập  từ bàn phím theo thứ tự tăng dần
class Program
{
    static void SapXepMang(float[] arr)
    {
        int n = arr.Length;
        for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - i - 1; j++)
            {
                if (arr[j] > arr[j + 1])
                {
                    // Hoán đổi arr[j] và arr[j + 1]
                    float temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        // Nhập số lượng phần tử
        Console.Write("Nhập số lượng phần tử của mảng: ");
        int n = int.Parse(Console.ReadLine());
        // Khởi tạo mảng
        float[] numbers = new float[n];
        // Nhập từng phần tử
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Nhập phần tử thứ {i + 1}: ");
            numbers[i] = float.Parse(Console.ReadLine());
        }
        // Gọi hàm sắp xếp
        SapXepMang(numbers);
        // Hiển thị kết quả
        Console.WriteLine("Mảng sau khi sắp xếp theo thứ tự tăng dần:");
        foreach (float num in numbers)
        {
            Console.Write(num + " ");
        }
    }

}
