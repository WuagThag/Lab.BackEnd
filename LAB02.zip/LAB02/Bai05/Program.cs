﻿using System;
namespace Bai05;
class Program
{
    static int FindSecondLargest(int[] arr)
    {
        if (arr.Length < 2)
        {
            throw new ArgumentException("Mang phai chưa it nhat hai phan tu.");
        }

        int max = int.MinValue;
        int secondMax = int.MinValue;

        foreach (int num in arr)
        {
            if (num > max)
            {
                secondMax = max;
                max = num;
            }
            else if (num > secondMax && num != max)
            {
                secondMax = num;
            }
        }

        if (secondMax == int.MinValue)
        {
            throw new InvalidOperationException("Không tìm thấy số lớn thứ hai (có thể tất cả các phần tử đều giống nhau).");
        }

        return secondMax;
    }

    static void Main()
    {
        Console.Write("Nhap so luong phan tu cua mang: ");
        int n = int.Parse(Console.ReadLine());

        int[] numbers = new int[n];
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Nhap phan tu thu {i + 1}: ");
            numbers[i] = int.Parse(Console.ReadLine());
        }

        try
        {
            int result = FindSecondLargest(numbers);
            Console.WriteLine("So lon thu hai trong mang la: " + result);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Lỗi: " + ex.Message);
        }
    }
}
